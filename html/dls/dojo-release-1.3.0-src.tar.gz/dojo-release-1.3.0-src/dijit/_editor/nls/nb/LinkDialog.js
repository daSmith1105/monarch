({
	createLinkTitle: "Koblingsegenskaper",
	insertImageTitle: "Bildeegenskaper",
	url: "URL:",
	text: "Beskrivelse:",
	set: "Definer"
})
