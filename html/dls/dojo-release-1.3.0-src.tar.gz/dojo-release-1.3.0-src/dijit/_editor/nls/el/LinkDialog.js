({
	createLinkTitle: "Ιδιότητες διασύνδεσης",
	insertImageTitle: "Ιδιότητες εικόνας",
	url: "Διεύθυνση URL:",
	text: "Περιγραφή:",
	set: "Ορισμός"
})
