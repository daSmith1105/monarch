({
	createLinkTitle: "Lastnosti povezave",
	insertImageTitle: "Lastnosti slike",
	url: "URL:",
	text: "Opis:",
	set: "Nastavi"
})

