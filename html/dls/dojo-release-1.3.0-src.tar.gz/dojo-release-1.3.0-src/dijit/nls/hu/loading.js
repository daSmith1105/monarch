({
	loadingState: "Betöltés...",
	errorState: "Sajnálom, hiba történt"
})
